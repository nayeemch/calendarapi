<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>CalendarAPI</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/roboto.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/ripples.min.css">
</head>

<body>
    <div class="navbar navbar-default">
        <div class="container">
            <div class="main-menu-container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Calendar<span style="font-weight: normal">API</span></a>
                </div>
                <div class="navbar-collapse collapse navbar-inverse-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('create' ,$id )); ?>">Add New</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <?php if($errors->any()): ?> <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-dismissible alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Oh snap!</strong> <?php echo e($error); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title text-center">Edit New Holiday</h3>
                <div class="panel-body">
                    <form class="form-horizontal" action="<?php echo e(route('update',$holiday->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="holiday_name" class="col-md-2 control-label">Holiday Name</label>
                            <div class="col-md-10">
                                <input class="form-control" id="holiday_name" name="holiday_name" placeholder="holiday_name Here" value="<?php echo e($holiday->holiday_name); ?>" type="text" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="holiday_details" class="col-md-2 control-label">Holiday Details</label>
                            <div class="col-md-10">
                                <input class="form-control" id="holiday_details" name="holiday_details" placeholder="holiday_details" value="<?php echo e($holiday->holiday_details); ?>" type="text" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="holiday_img_url" class="col-md-2 control-label">Holiday Image URL</label>
                            <div class="col-md-10">
                                <input class="form-control" id="holiday_img_url" name="holiday_img_url" placeholder="Holiday Image URL here" value="<?php echo e($holiday->holiday_img_url); ?>" type="text" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="holiday_date" class="col-md-2 control-label">Holiday Date</label>
                            <div class="col-md-10">
                                <input class="form-control" id="holiday_date" name="holiday_date" placeholder="Holiday Date here" value="<?php echo e($holiday->holiday_date); ?>" type="text" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="holiday_year" class="col-md-2 control-label">Holiday Year</label>
                            <div class="col-md-10">
                                <input class="form-control" id="holiday_year" name="holiday_year" placeholder="Holiday Year here" value="<?php echo e($holiday->holiday_year); ?>" type="text" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="months_name" class="col-md-2 control-label">Holiday Months Name</label>
                            <div class="col-md-10">
                                <div class="col-md-10">
                                <select class="form-control" id="months_id" name="months_id">
                                    <?php $__currentLoopData = $months_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($month->id); ?>" <?php if($holiday->months_id==$month->id) echo "selected"?>><?php echo e($month->months_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        
                            <input type="hidden" name="calendar_type_id" value="<?php echo e($holiday->calendar_type_id); ?>">

                            </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-2">
                                <!-- <button type="button" class="btn btn-default">Cancel</button> -->
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- panel-body -->
            </div>
            <!-- panel-heading -->
        </div>
        <!-- panel panel-default -->
    </div>
    <!-- container -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/ripples.min.js"></script>
    <script type="text/javascript">
    $.material.init()
    </script>
</body>

</html>