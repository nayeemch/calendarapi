<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>CalendarAPI</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/roboto.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/ripples.min.css">
</head>

<body>
    <div class="navbar navbar-default">
        <div class="container">
            <div class="main-menu-container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Calendar<span style="font-weight: normal">API</span></a>
                </div>
                <div class="navbar-collapse collapse navbar-inverse-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        
                        <li><a href="<?php echo e(route('create',$id)); ?>">Add New</a></li>

                        

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <?php if(session('successMsg')): ?>
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Well done!</strong> <?php echo e(session('successMsg')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="container">
        <table class="table table-striped table-hover table-bordered">
            <thead>
                <div class="col-md-5">
                    <form action="<?php echo e(route('home')); ?>" method="GET" class="search">
                        <div class="form-group center-align">
                            <input class="form-control" id="holiday_name" placeholder="Search holiday here" type="text" name="holiday_name">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Holiday Name</th>
                    <th class="text-center">Holiday Details</th>
                    <th class="text-center">Holiday Image Url</th>
                    <th class="text-center">Holiday Date</th>
                    <th class="text-center">Holiday Month</th>
                    <th class="text-center">Holiday Year</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $showData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($holiday->id); ?></td>
                    <td class="text-center"><?php echo e($holiday->holiday_name); ?></td>
                    <td class="text-center"><?php echo e($holiday->holiday_details); ?></td>
                    <td class="text-center"><?php echo e($holiday->holiday_img_url); ?></td>
                    <td class="text-center"><?php echo e($holiday->holiday_date); ?></td>
                    <td class="text-center"><?php echo e($holiday->months_name); ?></td>
                    <td class="text-center"><?php echo e($holiday->holiday_year); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('edit',$holiday->id)); ?>" class="btn btn-raised btn-sm btn-primary">Edit</a> |
                        <form method="POST" style="display: none;" id="delete-form-<?php echo e($holiday->id); ?>" action="<?php echo e(route('delete',$holiday->id)); ?>">
                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('delete')); ?>

                        </form>
                        <a onclick="if(confirm('Are you sure?')){
                event.preventDefault(); 
                document.getElementById('delete-form-<?php echo e($holiday->id); ?>').submit();
            } else{event.preventDefault();}" class="btn btn-raised btn-sm btn-danger">Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="text-center">
            
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/ripples.min.js"></script>
    <script type="text/javascript">
    $.material.init()
    </script>
</body>

</html>