<?php $__currentLoopData = $showData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<? json_encode($showdata);?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
